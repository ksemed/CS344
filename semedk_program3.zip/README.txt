Assignment 3, due 5/2/2022

Instructions:

1) Compile the program with

gcc --std=gnu99 -o smallsh main.c

2) Run the program with

./smallsh